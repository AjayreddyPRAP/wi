﻿namespace Partialview.Models
{
    public class ProductModel
    {

        public int pId { get; set; }
        public string pName { get; set; }
        public int pPrice { get; set; }
        public int pAvailabeQty { get; set; }
        public bool pIsInstock { get; set; }
        public string pCategory { get; set; }
        
    }
    static List<ProductModel> pList=new List<ProductModel>()
    {
        new ProductModel(){ pId=101,pName="pepsi",pCategory="cold-drinks",pAvailabeQty=10,pIsInstock=true,pPrice=50 },
        new ProductModel(){ pId=101,pName="pepsi",pCategory="cold-drinks",pAvailabeQty=10,pIsInstock=true,pPrice=50 },
        new ProductModel(){ pId=101,pName="pepsi",pCategory="cold-drinks",pAvailabeQty=10,pIsInstock=true,pPrice=50 },
        new ProductModel(){ pId=101,pName="pepsi",pCategory="cold-drinks",pAvailabeQty=10,pIsInstock=true,pPrice=50 },
        new ProductModel(){ pId=101,pName="pepsi",pCategory="cold-drinks",pAvailabeQty=10,pIsInstock=true,pPrice=50 },
        new ProductModel(){ pId=101,pName="pepsi",pCategory="cold-drinks",pAvailabeQty=10,pIsInstock=true,pPrice=50 },
    }
}
