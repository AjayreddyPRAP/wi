﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Identify_Framework.Controllers
{
    public class BankingController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Bankinginfo()
        {
            return View();
        }
        public IActionResult Upcomingevents()
        {
            return View();
        }
        [Authorize]
        public IActionResult Transferfounds()
        {
            return View();
        }
        [Authorize]
        public IActionResult Downloadstatements()
        {
            return View();
        }
    }
}
