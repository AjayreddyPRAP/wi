﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using mvc_dataanetations.Models.EF;

namespace mvc_dataanetations.Controllers
{
    public class ParticapantsController : Controller
    {
        private readonly ParticepentsContext _context=new ParticepentsContext();

        public ParticapantsController(ParticepentsContext context)
        {
            _context = context;
        }

        // GET: Particapants
       // public async Task<IActionResult> Index()
       // {
           //   return _context.Particapants != null ? 
                        //  View(await _context.Particapants.ToListAsync()) :
                          //Problem("Entity set 'ParticepentsContext.Particapants'  is null.");
       // }

        //GET: Particapants/Details/5
        
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Particapants == null)
            {
                return NotFound();
            }

            var particapant = await _context.Particapants
                .FirstOrDefaultAsync(m => m.PId == id);
            if (particapant == null)
            {
                return NotFound();
            }

            return View(particapant);
        }

        // GET: Particapants/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Particapants/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PId,PName,PDesignation,PFavTechnology,PCity,PEmailAddress,PMobile")] Particapant particapant)
        {
            if (ModelState.IsValid)
            {
                _context.Add(particapant);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(particapant);
        }

        // GET: Particapants/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Particapants == null)
            {
                return NotFound();
            }

            var particapant = await _context.Particapants.FindAsync(id);
            if (particapant == null)
            {
                return NotFound();
            }
            return View(particapant);
        }

        // POST: Particapants/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PId,PName,PDesignation,PFavTechnology,PCity,PEmailAddress,PMobile")] Particapant particapant)
        {
            if (id != particapant.PId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(particapant);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ParticapantExists(particapant.PId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(particapant);
        }

        // GET: Particapants/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Particapants == null)
            {
                return NotFound();
            }

            var particapant = await _context.Particapants
                .FirstOrDefaultAsync(m => m.PId == id);
            if (particapant == null)
            {
                return NotFound();
            }

            return View(particapant);
        }

        // POST: Particapants/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Particapants == null)
            {
                return Problem("Entity set 'ParticepentsContext.Particapants'  is null.");
            }
            var particapant = await _context.Particapants.FindAsync(id);
            if (particapant != null)
            {
                _context.Particapants.Remove(particapant);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ParticapantExists(int id)
        {
          return (_context.Particapants?.Any(e => e.PId == id)).GetValueOrDefault();
        }
    }
}
