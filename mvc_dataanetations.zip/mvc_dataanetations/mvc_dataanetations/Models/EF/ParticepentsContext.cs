﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace mvc_dataanetations.Models.EF
{
    public partial class ParticepentsContext : DbContext
    {
        public ParticepentsContext()
        {
        }

        public ParticepentsContext(DbContextOptions<ParticepentsContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Particapant> Particapants { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=tcp:prctice-serever.database.windows.net,1433;Initial Catalog=Particepents;Persist Security Info=False;User ID=ajay;Password=Reddy@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Particapant>(entity =>
            {
                entity.HasKey(e => e.PId)
                    .HasName("PK__Particap__DD36D5625C42E36E");

                entity.ToTable("Particapant");

                entity.Property(e => e.PId).HasColumnName("pId");

                entity.Property(e => e.PCity)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("pCity");

                entity.Property(e => e.PDesignation)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("pDesignation");

                entity.Property(e => e.PEmailAddress)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("pEmailAddress");

                entity.Property(e => e.PFavTechnology)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("pFavTechnology");

                entity.Property(e => e.PMobile)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("pMobile");

                entity.Property(e => e.PName)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("pName");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
