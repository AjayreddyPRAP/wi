﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
namespace mvc_dataanetations.Models.EF
{
    public partial class Particapant
    {
        public int PId { get; set; }
        [Display (Name ="Particapant Name")]
        [Required(AllowEmptyStrings = false,ErrorMessage ="name is mandatory ,please provide a valid name")]
        [StringLength(20,MinimumLength =3,ErrorMessage ="name should be 3 to 20 charectors")]
        public string? PName { get; set; }
        public string? PDesignation { get; set; }
        public string? PFavTechnology { get; set; }
        public string? PCity { get; set; }
        [Display (Name="email id") ]
        [EmailAddress (ErrorMessage = "this is not a valid email address")]
        public string? PEmailAddress { get; set; }
        public string? PMobile { get; set; }
    }
}
